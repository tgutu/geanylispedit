tar --exclude=geanylispedit.tar.gz --exclude=HOWTO --exclude=src/geanylispedit.*o -czf geanylispedit.tar.gz *
