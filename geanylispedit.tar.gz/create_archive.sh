tar --exclude=geanylispedit.tar.gz --exclude=src/geanylispedit.*o -czf geanylispedit.tar.gz *
