--[[
  Rebuild the scripts menu
--]]

geany.rescan()
