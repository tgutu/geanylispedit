
/* Generated data (by glib-mkenums) */

#include "gwh-enum-types.h"

/* enumerations from "./gwh-browser.h" */
GType
gwh_browser_position_get_type (void)
{
  static GType etype = 0;
  if (G_UNLIKELY(etype == 0)) {
    static const GEnumValue values[] = {
      { GWH_BROWSER_POSITION_MESSAGE_WINDOW, "GWH_BROWSER_POSITION_MESSAGE_WINDOW", "message-window" },
      { GWH_BROWSER_POSITION_SIDEBAR, "GWH_BROWSER_POSITION_SIDEBAR", "sidebar" },
      { GWH_BROWSER_POSITION_SEPARATE_WINDOW, "GWH_BROWSER_POSITION_SEPARATE_WINDOW", "separate-window" },
      { 0, NULL, NULL }
    };
    etype = g_enum_register_static (g_intern_static_string ("GwhBrowserPosition"), values);
  }
  return etype;
}


/* Generated data ends here */

